// src/pages/operations/order-detail.jsx
import { useState, useEffect } from "react";
import { useParams, Link } from "wouter";
import {
  useGetOperationsOrder,
  useFetchComprehensiveReportData,
  useSaveAnalystEnrichment,
  useRunDecisionModels,
  useGeneratePdfReport,
  usePublishOrder,
} from "@/lib/api";
import { useQueryClient } from "@tanstack/react-query";
import {
  Card,
  Button,
  StatusBadge,
  PriorityBadge,
  Label,
  Textarea,
  Input,
} from "@/components/ui-shared";
import { formatDate } from "@/lib/utils";
import {
  ArrowLeft,
  Building2,
  Users,
  DollarSign,
  Scale,
  FileText,
  Save,
  Play,
  FileOutput,
  Send,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Shield,
  ChevronDown,
  ChevronUp,
  Download,
  Loader2,
  RefreshCw,
  Clock,
  Plus,
  X,
} from "lucide-react";

function SectionCard({ title, icon: Icon, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <Card className="overflow-hidden">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-100 hover:bg-slate-100 transition-colors text-left"
      >
        <div className="flex items-center gap-2 font-semibold text-slate-800">
          <Icon className="w-4 h-4 text-blue-600" />
          {title}
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
      </button>
      {open && <div className="p-6">{children}</div>}
    </Card>
  );
}

function KV({ label, value, mono = false }) {
  return (
    <div>
      <dt className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">{label}</dt>
      <dd className={`text-sm text-slate-800 font-medium ${mono ? "font-mono" : ""}`}>{value || "\u2014"}</dd>
    </div>
  );
}

function InfoGrid({ items }) {
  return (
    <dl className="grid grid-cols-2 gap-x-8 gap-y-4">
      {items.map((i) => <KV key={i.label} {...i} />)}
    </dl>
  );
}

function StepBadge({ done, active, label }) {
  return (
    <div className={`flex items-center gap-2 text-sm font-medium px-3 py-1.5 rounded-full ${done ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : active ? "bg-blue-50 text-blue-700 border border-blue-200" : "bg-slate-50 text-slate-400 border border-slate-200"}`}>
      {done ? <CheckCircle2 className="w-4 h-4" /> : <div className={`w-4 h-4 rounded-full border-2 ${active ? "border-blue-500" : "border-slate-300"}`} />}
      {label}
    </div>
  );
}

const RATING_COLORS = {
  "A+": "text-emerald-700 bg-emerald-50 border-emerald-300",
  A: "text-emerald-700 bg-emerald-50 border-emerald-300",
  "A-": "text-emerald-700 bg-emerald-50 border-emerald-300",
  "B+": "text-amber-700 bg-amber-50 border-amber-300",
  B: "text-amber-700 bg-amber-50 border-amber-300",
  "B-": "text-orange-700 bg-orange-50 border-orange-300",
  C: "text-red-700 bg-red-50 border-red-300",
  D: "text-red-900 bg-red-100 border-red-400",
};

const RISK_COLORS = {
  Low: "bg-emerald-50 border-emerald-200 text-emerald-700",
  "Low-Medium": "bg-green-50 border-green-200 text-green-700",
  Medium: "bg-amber-50 border-amber-200 text-amber-700",
  "Medium-High": "bg-orange-50 border-orange-200 text-orange-700",
  High: "bg-red-50 border-red-200 text-red-700",
  "Very High": "bg-red-100 border-red-300 text-red-900",
};

function formatINR(n) {
  if (n >= 1e7) return `\u20B9${(n / 1e7).toFixed(2)} Cr`;
  if (n >= 1e5) return `\u20B9${(n / 1e5).toFixed(2)} L`;
  return `\u20B9${n.toLocaleString("en-IN")}`;
}

function OpsOrderDetail() {
  const routeParams = useParams();
  const id = Number(routeParams?.id);
  const queryClient = useQueryClient();

  const { data: order, isLoading } = useGetOperationsOrder(id);
  const fetchMut = useFetchComprehensiveReportData();
  const enrichMut = useSaveAnalystEnrichment();
  const modelMut = useRunDecisionModels();
  const pdfMut = useGeneratePdfReport();
  const publishMut = usePublishOrder();

  const [activeTab, setActiveTab] = useState("data");
  const [investigationSummary, setInvestigationSummary] = useState("");
  const [analystComments, setAnalystComments] = useState("");
  const [recommendationNotes, setRecommendationNotes] = useState("");
  const [redFlags, setRedFlags] = useState([]);
  const [newFlag, setNewFlag] = useState("");
  const [toastMsg, setToastMsg] = useState(null);
  const [localReport, setLocalReport] = useState(null);
  const [localDecision, setLocalDecision] = useState(null);

  useEffect(() => {
    if (order?.analystEnrichment) {
      setInvestigationSummary(order.analystEnrichment.investigationSummary || "");
      setAnalystComments(order.analystEnrichment.analystComments || "");
      setRecommendationNotes(order.analystEnrichment.recommendationNotes || "");
      setRedFlags(order.analystEnrichment.redFlags || []);
      if (order.analystEnrichment.decisionOutputs) {
        setLocalDecision(order.analystEnrichment.decisionOutputs);
      }
    }
    if (order?.providerSearchSnapshot?.rawResults) {
      setLocalReport(order.providerSearchSnapshot.rawResults);
    }
  }, [order]);

  const toast = (type, text) => {
    setToastMsg({ type, text });
    setTimeout(() => setToastMsg(null), 3500);
  };

  const invalidate = () => queryClient.invalidateQueries({ queryKey: [`opsOrder-${id}`] });

  if (!id || isNaN(id)) {
    return (
      <div className="p-8 text-center text-red-500">
        Invalid order ID. <Link href="~/operations/orders" className="text-blue-600 underline">Back to Queue</Link>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-10 h-10 animate-spin mb-4" />
        Loading order workbench...
      </div>
    );
  }

  if (!order) {
    return (
      <div className="p-8 text-center text-red-500">
        Order not found. <Link href="~/operations/orders" className="text-blue-600 underline">Back to Queue</Link>
      </div>
    );
  }

  const st = order.status;
  const hasData = !!(order.providerSearchSnapshot || localReport);
  const hasModels = !!(localDecision || order.analystEnrichment?.decisionOutputs);
  const hasPdf = order.generatedDocuments?.some((d) => d.documentType === "due_diligence_report" && d.status === "ready");
  const isCompleted = st === "completed";

  const handleFetchData = () => {
    fetchMut.mutate({ id }, {
      onSuccess: (data) => {
        setLocalReport(data.report);
        invalidate();
        toast("success", "Company data fetched successfully");
        setActiveTab("data");
      },
      onError: () => toast("error", "Failed to fetch company data"),
    });
  };

  const handleSaveEnrichment = (isDraft) => {
    enrichMut.mutate({ id, data: { investigationSummary, analystComments, redFlags, recommendationNotes, isDraft } }, {
      onSuccess: () => {
        invalidate();
        toast("success", isDraft ? "Draft saved" : "Investigation notes submitted");
      },
      onError: () => toast("error", "Failed to save"),
    });
  };

  const handleRunModels = () => {
    modelMut.mutate({ id }, {
      onSuccess: (data) => {
        setLocalDecision(data);
        invalidate();
        toast("success", "Decision engine models executed");
        setActiveTab("decision");
      },
      onError: (err) => toast("error", err?.message || "Failed to run models"),
    });
  };

  const handleGeneratePdf = () => {
    pdfMut.mutate({ id }, {
      onSuccess: () => {
        invalidate();
        toast("success", "PDF report generated");
        setActiveTab("publish");
      },
      onError: (err) => toast("error", err?.message || "Failed to generate PDF"),
    });
  };

  const handlePublish = () => {
    publishMut.mutate({ id }, {
      onSuccess: () => {
        invalidate();
        toast("success", "Report published and client notified!");
      },
      onError: (err) => toast("error", err?.message || "Failed to publish"),
    });
  };

  const report = localReport || order.providerSearchSnapshot?.rawResults;
  const decision = localDecision || order.analystEnrichment?.decisionOutputs;

  const TABS = [
    { id: "data", label: "Company Data", icon: Building2 },
    { id: "notes", label: "Analyst Notes", icon: FileText },
    { id: "decision", label: "Decision Engine", icon: TrendingUp },
    { id: "publish", label: "Publish", icon: Send },
  ];

  return (
    <div className="pb-16 relative">
      {toastMsg && (
        <div className={`fixed top-6 right-6 z-50 px-5 py-3 rounded-2xl shadow-xl font-medium text-sm flex items-center gap-2 transition-all ${toastMsg.type === "success" ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
          {toastMsg.type === "success" ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          {toastMsg.text}
        </div>
      )}

      <div className="mb-6">
        <Link href="~/operations/orders" className="text-slate-500 hover:text-slate-900 inline-flex items-center text-sm font-medium transition-colors">
          <ArrowLeft className="w-4 h-4 mr-1" /> Back to Queue
        </Link>
      </div>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-3 flex-wrap mb-1">
            <h1 className="text-2xl font-bold text-slate-900">{order.subjectName}</h1>
            <StatusBadge status={order.status} />
            <PriorityBadge priority={order.priority} />
          </div>
          <p className="text-slate-500 text-sm">
            {order.orderNumber} &bull; {order.clientCompanyName || "\u2014"} &bull; {order.productName || "DDR"} &bull; Submitted {formatDate(order.createdAt)}
          </p>
          {order.subjectDetails?.cin && <p className="text-xs font-mono text-slate-400 mt-1">CIN: {order.subjectDetails.cin}</p>}
        </div>
      </div>

      {/* Workflow Progress */}
      <div className="flex flex-wrap gap-2 mb-8">
        <StepBadge done={hasData} active={!hasData} label="Data Fetched" />
        <StepBadge done={!!order.analystEnrichment?.investigationSummary} active={hasData && !order.analystEnrichment?.investigationSummary} label="Notes Written" />
        <StepBadge done={hasModels} active={!!order.analystEnrichment?.investigationSummary && !hasModels} label="Models Run" />
        <StepBadge done={hasPdf} active={hasModels && !hasPdf} label="PDF Generated" />
        <StepBadge done={isCompleted} active={hasPdf && !isCompleted} label="Published" />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-slate-200 mb-8 overflow-x-auto">
        {TABS.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 -mb-px transition-colors whitespace-nowrap ${activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-slate-500 hover:text-slate-900"}`}>
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── TAB: Company Data ── */}
      {activeTab === "data" && (
        <div className="space-y-5">
          {!hasData ? (
            <Card className="p-12 text-center">
              <Building2 className="w-14 h-14 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-700 mb-2">No Data Fetched Yet</h3>
              <p className="text-slate-500 text-sm mb-6">Fetch comprehensive company data from the registry to begin analysis.</p>
              <Button size="lg" onClick={handleFetchData} isLoading={fetchMut.isPending}>
                <RefreshCw className="w-4 h-4 mr-2" /> Fetch Company Data
              </Button>
            </Card>
          ) : (
            <>
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={handleFetchData} isLoading={fetchMut.isPending}>
                  <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Re-fetch Data
                </Button>
              </div>
              {report && (
                <>
                  <SectionCard title="Company Profile" icon={Building2}>
                    <InfoGrid items={[
                      { label: "Company Name", value: report.companyProfile?.name },
                      { label: "CIN", value: report.companyProfile?.cin, mono: true },
                      { label: "Type", value: report.companyProfile?.companyType },
                      { label: "Category", value: report.companyProfile?.category },
                      { label: "Date of Incorporation", value: report.companyProfile?.dateOfIncorporation },
                      { label: "Listing Status", value: report.companyProfile?.listingStatus },
                      { label: "Authorized Capital", value: report.companyProfile?.authorizedCapital },
                      { label: "Paid-up Capital", value: report.companyProfile?.paidUpCapital },
                    ]} />
                    <div className="mt-5 pt-5 border-t border-slate-100">
                      <KV label="Registered Office" value={report.companyProfile?.registeredOffice} />
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-4">
                      <KV label="Activity" value={report.companyProfile?.activityDescription} />
                      <KV label="NIC Code" value={report.companyProfile?.nicCode} />
                    </div>
                  </SectionCard>

                  <SectionCard title="Registration Details" icon={FileText}>
                    <InfoGrid items={[
                      { label: "PAN", value: report.registrationDetails?.pan, mono: true },
                      { label: "GSTIN", value: report.registrationDetails?.gstin, mono: true },
                      { label: "TAN", value: report.registrationDetails?.tan, mono: true },
                      { label: "IEC", value: report.registrationDetails?.importExportCode, mono: true },
                      { label: "ROC Code", value: report.registrationDetails?.rocCode },
                      { label: "Signatories", value: String(report.registrationDetails?.signatoriesCount || "\u2014") },
                      { label: "Last Balance Sheet", value: report.registrationDetails?.lastBalanceSheetDate },
                      { label: "Last Annual Return", value: report.registrationDetails?.lastAnnualReturnDate },
                    ]} />
                  </SectionCard>

                  <SectionCard title={`Directors / Management (${report.directors?.length || 0})`} icon={Users}>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-500">
                            <th className="pb-2 text-xs font-semibold text-left">Name</th>
                            <th className="pb-2 text-xs font-semibold text-left">Designation</th>
                            <th className="pb-2 text-xs font-semibold text-left">DIN</th>
                            <th className="pb-2 text-xs font-semibold text-left">Appointed</th>
                            <th className="pb-2 text-xs font-semibold text-left">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          {report.directors?.map((d, i) => (
                            <tr key={i} className="hover:bg-slate-50">
                              <td className="py-2.5 font-semibold text-slate-800">{d.name}</td>
                              <td className="py-2.5 text-slate-500">{d.designation}</td>
                              <td className="py-2.5 font-mono text-xs text-slate-400">{d.din}</td>
                              <td className="py-2.5 text-slate-500">{d.dateOfAppointment}</td>
                              <td className="py-2.5">
                                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${d.isActive ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                                  {d.isActive ? "Active" : "Ceased"}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </SectionCard>

                  <SectionCard title="Financial Summary" icon={DollarSign}>
                    <InfoGrid items={[
                      { label: "Revenue / Turnover", value: report.financialSummary?.revenue },
                      { label: "Net Profit / (Loss)", value: report.financialSummary?.netProfit },
                      { label: "EBITDA", value: report.financialSummary?.ebitda },
                      { label: "Total Assets", value: report.financialSummary?.totalAssets },
                      { label: "Total Liabilities", value: report.financialSummary?.totalLiabilities },
                      { label: "Net Worth", value: report.financialSummary?.netWorth },
                      { label: "D/E Ratio", value: report.financialSummary?.debtEquityRatio ? report.financialSummary.debtEquityRatio + "x" : null },
                      { label: "Current Ratio", value: report.financialSummary?.currentRatio ? report.financialSummary.currentRatio + "x" : null },
                      { label: "Profit Margin", value: report.financialSummary?.profitMargin },
                      { label: "Return on Equity", value: report.financialSummary?.returnOnEquity },
                      { label: "Cash & Equivalents", value: report.financialSummary?.cashAndEquivalents },
                      { label: "Filing Year", value: report.financialSummary?.lastFilingYear },
                    ]} />
                  </SectionCard>

                  <SectionCard title={`Charges / Liens (${report.charges?.length || 0})`} icon={Scale} defaultOpen={true}>
                    {report.charges?.length === 0 ? (
                      <p className="text-slate-400 text-sm">No charges recorded.</p>
                    ) : (
                      <div className="space-y-3">
                        {report.charges?.map((c, i) => (
                          <div key={i} className={`p-4 rounded-xl border ${c.status === "Open" ? "border-red-200 bg-red-50" : "border-slate-200 bg-slate-50"}`}>
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="font-semibold text-slate-800 text-sm">{c.chargeHolder}</div>
                                <div className="text-xs text-slate-500 mt-0.5">{c.nature}</div>
                              </div>
                              <div className="text-right">
                                <div className={`text-xs font-bold px-2 py-0.5 rounded-full ${c.status === "Open" ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`}>{c.status}</div>
                                <div className="text-sm font-bold text-slate-700 mt-1">{c.amount}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </SectionCard>

                  <SectionCard title="Legal / Compliance" icon={Scale}>
                    <InfoGrid items={[
                      { label: "Compliance Rating", value: report.legalCompliance?.complianceRating },
                      { label: "Pending Litigation", value: String(report.legalCompliance?.pendingLitigation ?? "\u2014") },
                      { label: "Suit Filed Cases", value: String(report.legalCompliance?.suitFiledCases ?? "\u2014") },
                      { label: "Wilful Defaulter", value: report.legalCompliance?.wilfulDefaulter ? "\u26A0 YES" : "No" },
                    ]} />
                    {(report.legalCompliance?.adverseFindings?.length > 0 || report.legalCompliance?.regulatoryActions?.length > 0) && (
                      <div className="mt-4 space-y-2">
                        {report.legalCompliance?.adverseFindings?.map((f, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm text-red-700 bg-red-50 rounded-lg p-3 border border-red-100">
                            <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />{f}
                          </div>
                        ))}
                        {report.legalCompliance?.regulatoryActions?.map((a, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm text-amber-700 bg-amber-50 rounded-lg p-3 border border-amber-100">
                            <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />{a}
                          </div>
                        ))}
                      </div>
                    )}
                  </SectionCard>

                  <div className="flex justify-end pt-4">
                    <Button onClick={() => setActiveTab("notes")} size="lg">Continue to Analyst Notes →</Button>
                  </div>
                </>
              )}
            </>
          )}
        </div>
      )}

      {/* ── TAB: Analyst Notes ── */}
      {activeTab === "notes" && (
        <div className="space-y-6">
          {!hasData && (
            <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-sm font-medium">
              <AlertTriangle className="w-4 h-4" /> Fetch company data first for context before writing notes.
            </div>
          )}
          <Card className="p-6">
            <h3 className="font-bold text-slate-800 mb-5 flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" /> Investigation & Analysis
            </h3>
            <div className="space-y-5">
              <div>
                <Label>Investigation Summary *</Label>
                <Textarea value={investigationSummary} onChange={(e) => setInvestigationSummary(e.target.value)} className="h-36" placeholder="Summarize your investigation findings..." />
              </div>
              <div>
                <Label>Analyst Comments</Label>
                <Textarea value={analystComments} onChange={(e) => setAnalystComments(e.target.value)} className="h-28" placeholder="Additional observations, context, or concerns..." />
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500" /> Red Flags
            </h3>
            <div className="space-y-2 mb-4">
              {redFlags.length === 0 && <p className="text-slate-400 text-sm italic">No red flags added.</p>}
              {redFlags.map((flag, i) => (
                <div key={i} className="flex items-center gap-2 bg-red-50 border border-red-100 rounded-lg px-4 py-2.5 text-sm text-red-700">
                  <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="flex-1">{flag}</span>
                  <button onClick={() => setRedFlags((fs) => fs.filter((_, j) => j !== i))} className="text-red-400 hover:text-red-700"><X className="w-3.5 h-3.5" /></button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input placeholder="Add a red flag..." value={newFlag} onChange={(e) => setNewFlag(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && newFlag.trim()) { setRedFlags((fs) => [...fs, newFlag.trim()]); setNewFlag(""); } }} />
              <Button variant="outline" size="md" onClick={() => { if (newFlag.trim()) { setRedFlags((fs) => [...fs, newFlag.trim()]); setNewFlag(""); } }}><Plus className="w-4 h-4" /></Button>
            </div>
          </Card>
          <Card className="p-6">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4 text-blue-600" /> Recommendation
            </h3>
            <Textarea value={recommendationNotes} onChange={(e) => setRecommendationNotes(e.target.value)} className="h-28" placeholder="Provide your final recommendation for the client..." />
          </Card>
          <div className="flex justify-between items-center pt-2">
            <Button variant="outline" onClick={() => handleSaveEnrichment(true)} isLoading={enrichMut.isPending}><Save className="w-4 h-4 mr-2" /> Save Draft</Button>
            <div className="flex gap-3">
              <Button variant="secondary" onClick={() => handleSaveEnrichment(false)} isLoading={enrichMut.isPending} disabled={!investigationSummary.trim()}>Submit Notes</Button>
              <Button onClick={() => setActiveTab("decision")}>Decision Engine →</Button>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB: Decision Engine ── */}
      {activeTab === "decision" && (
        <div className="space-y-6">
          {!hasModels ? (
            <Card className="p-12 text-center">
              <TrendingUp className="w-14 h-14 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-700 mb-2">Run Decision Engine</h3>
              <p className="text-slate-500 text-sm mb-6">Execute credit rating, risk scoring, and eligibility models on the fetched data.</p>
              <Button size="lg" onClick={handleRunModels} isLoading={modelMut.isPending} disabled={!hasData}>
                <Play className="w-4 h-4 mr-2" /> Run Models
              </Button>
              {!hasData && <p className="text-xs text-amber-600 mt-3">Fetch company data first before running models.</p>}
            </Card>
          ) : (
            <>
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={handleRunModels} isLoading={modelMut.isPending}>
                  <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Re-run Models
                </Button>
              </div>
              {decision && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-6">
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Credit Rating</h4>
                    <div className={`inline-flex items-center px-4 py-2 rounded-xl border-2 text-2xl font-bold ${RATING_COLORS[decision.creditRating?.rating] || "text-slate-700 bg-slate-50 border-slate-300"}`}>
                      {decision.creditRating?.rating || "N/A"}
                    </div>
                    <p className="text-sm text-slate-500 mt-3">{decision.creditRating?.rationale}</p>
                  </Card>
                  <Card className="p-6">
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Risk Score</h4>
                    <div className="text-3xl font-bold text-slate-900">{decision.riskScore?.score}<span className="text-base text-slate-400 font-normal"> / 100</span></div>
                    <div className={`inline-flex mt-2 px-3 py-1 rounded-full text-xs font-semibold border ${RISK_COLORS[decision.riskScore?.band] || "bg-slate-50 border-slate-200 text-slate-600"}`}>
                      {decision.riskScore?.band || "Unknown"}
                    </div>
                  </Card>
                  <Card className="p-6">
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Recommended Eligibility</h4>
                    <div className="text-lg font-bold text-slate-900">
                      {decision.eligibility ? (<>{formatINR(decision.eligibility.recommendedAmountMin || 0)}<span className="text-slate-400 mx-1">-</span>{formatINR(decision.eligibility.recommendedAmountMax || 0)}</>) : "N/A"}
                    </div>
                    <p className="text-xs text-slate-400 mt-1">{decision.eligibility?.currency || "INR"}</p>
                  </Card>
                </div>
              )}
              {decision?.keyRiskDrivers?.length > 0 && (
                <Card className="p-6">
                  <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" /> Key Risk Drivers
                  </h4>
                  <div className="space-y-2">
                    {decision.keyRiskDrivers.map((driver, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm text-slate-700 bg-amber-50 rounded-lg p-3 border border-amber-100">
                        <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />{driver}
                      </div>
                    ))}
                  </div>
                </Card>
              )}
              <div className="flex justify-end pt-4">
                <Button onClick={() => setActiveTab("publish")} size="lg">Continue to Publish →</Button>
              </div>
            </>
          )}
        </div>
      )}

      {/* ── TAB: Publish ── */}
      {activeTab === "publish" && (
        <div className="space-y-6">
          <Card className="p-8">
            <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2">
              <FileOutput className="w-5 h-5 text-blue-600" /> Generate & Publish Report
            </h3>
            <div className="space-y-4">
              <div className={`p-5 rounded-xl border ${hasPdf ? "border-emerald-200 bg-emerald-50" : "border-slate-200 bg-slate-50"}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {hasPdf ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <FileOutput className="w-5 h-5 text-slate-400" />}
                    <div>
                      <p className="font-semibold text-slate-800">Generate PDF Report</p>
                      <p className="text-xs text-slate-500 mt-0.5">{hasPdf ? "PDF ready for download" : "Create the due diligence report PDF"}</p>
                    </div>
                  </div>
                  <Button variant={hasPdf ? "outline" : "primary"} size="sm" onClick={handleGeneratePdf} isLoading={pdfMut.isPending} disabled={!hasData}>
                    {hasPdf ? "Re-generate" : "Generate PDF"}
                  </Button>
                </div>
              </div>
              <div className={`p-5 rounded-xl border ${isCompleted ? "border-emerald-200 bg-emerald-50" : "border-slate-200 bg-slate-50"}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {isCompleted ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <Send className="w-5 h-5 text-slate-400" />}
                    <div>
                      <p className="font-semibold text-slate-800">Publish Report</p>
                      <p className="text-xs text-slate-500 mt-0.5">{isCompleted ? "Report published and client notified" : "Make the report available to the client"}</p>
                    </div>
                  </div>
                  {!isCompleted && (
                    <Button size="sm" onClick={handlePublish} isLoading={publishMut.isPending} disabled={!hasPdf || !investigationSummary.trim()}>
                      <Send className="w-4 h-4 mr-1.5" /> Publish
                    </Button>
                  )}
                </div>
              </div>
            </div>
            {isCompleted && (
              <div className="mt-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                <p className="font-bold text-emerald-800">Report Published!</p>
                <p className="text-sm text-emerald-600 mt-1">The client has been notified and can now download the report.</p>
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}

export default OpsOrderDetail;
// src/pages/operations/order-detail.jsx
import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "wouter";
import {
  useGetOperationsOrder, useFetchComprehensiveReportData,
  useSaveAnalystEnrichment, useRunDecisionModels,
  useGeneratePdfReport, usePublishOrder,
} from "@/lib/api";
import { useQueryClient } from "@tanstack/react-query";
import { Card, Button, StatusBadge, PriorityBadge, Label, Textarea, Input } from "@/components/ui-shared";
import { formatDate } from "@/lib/utils";
import {
  ArrowLeft, Building2, Users, Scale, FileText, Save, Play,
  FileOutput, Send, CheckCircle2, AlertTriangle, TrendingUp, Shield,
  Loader2, RefreshCw, Plus, X, MapPin, Landmark, Network,
  BarChart3, PieChart, CreditCard, ListChecks, Gavel, BookOpen,
  BadgeAlert, Briefcase, ChevronDown, ChevronRight,
} from "lucide-react";

// ─── Helpers ───
function fmtCr(n) {
  if (!n && n !== 0) return "N/A";
  if (Math.abs(n) >= 1e7) return `₹${(n / 1e7).toFixed(2)} Cr`;
  if (Math.abs(n) >= 1e5) return `₹${(n / 1e5).toFixed(2)} L`;
  return `₹${Number(n).toLocaleString("en-IN")}`;
}
function fmtPct(n) { return n != null ? `${n.toFixed(2)}%` : "N/A"; }
function SevBadge({ severity }) {
  const c = { CRITICAL: "bg-red-100 text-red-700", HIGH: "bg-orange-100 text-orange-700", MEDIUM: "bg-yellow-100 text-yellow-700", LOW: "bg-green-100 text-green-700" };
  return <span className={`px-2 py-0.5 rounded text-xs font-semibold ${c[(severity || "").toUpperCase()] || "bg-slate-100 text-slate-600"}`}>{severity}</span>;
}
function KV({ label, value, mono }) {
  return <div className="flex items-start gap-3 py-2.5 border-b border-slate-100 last:border-0">
    <span className="text-sm text-slate-500 min-w-[140px] shrink-0">{label}</span>
    <span className={`text-sm font-medium text-slate-800 ${mono ? "font-mono" : ""}`}>{value || "—"}</span>
  </div>;
}
function StatCard({ label, value, sub }) {
  return <div className="bg-white border border-slate-200 rounded-xl p-4">
    <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">{label}</p>
    <p className="text-xl font-bold text-slate-900 mt-1">{value}</p>
    {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
  </div>;
}
function SectionHead({ icon: Icon, title, count }) {
  return <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2 mb-4">
    <Icon className="w-5 h-5 text-blue-600" /> {title}
    {count != null && <span className="text-sm font-normal text-slate-400 ml-1">({count})</span>}
  </h2>;
}
function ShowMore({ items, renderItem, initialCount = 10, label = "items" }) {
  const [showAll, setShowAll] = useState(false);
  if (!items?.length) return null;
  const visible = showAll ? items : items.slice(0, initialCount);
  const remaining = items.length - initialCount;
  return <>{visible.map(renderItem)}{remaining > 0 && !showAll && (
    <button onClick={() => setShowAll(true)} className="w-full py-2.5 text-center text-sm font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg mt-2 transition-colors">
      Show {remaining} more {label}
    </button>
  )}{showAll && remaining > 0 && (
    <button onClick={() => setShowAll(false)} className="w-full py-2.5 text-center text-sm font-medium text-slate-500 hover:bg-slate-50 rounded-lg mt-2">
      Show less
    </button>
  )}</>;
}

// ─── Section navigation config ───
const DATA_SECTIONS = [
  { id: "overview", label: "Overview", icon: Building2 },
  { id: "directors", label: "Directors", icon: Users },
  { id: "dirNetwork", label: "Director Network", icon: Network },
  { id: "financials", label: "Financials", icon: BarChart3 },
  { id: "charges", label: "Charges", icon: Landmark },
  { id: "legalHistory", label: "Legal History", icon: Gavel },
  { id: "defaults", label: "Defaults & Credit", icon: BadgeAlert },
  { id: "risk", label: "Risk Flags", icon: AlertTriangle },
  { id: "gst", label: "GST", icon: Scale },
  { id: "shareholding", label: "Shareholding", icon: PieChart },
  { id: "securities", label: "Securities", icon: CreditCard },
  { id: "epfo", label: "EPFO", icon: Briefcase },
  { id: "addresses", label: "Addresses", icon: MapPin },
  { id: "filings", label: "Filings", icon: FileText },
  { id: "contact", label: "Contact", icon: BookOpen },
];

// ─── Company Data Panel with vertical sidebar ───
function CompanyDataPanel({ report }) {
  const [activeSection, setActiveSection] = useState("overview");
  const sectionRefs = useRef({});
  const scrollToSection = (sid) => { setActiveSection(sid); sectionRefs.current[sid]?.scrollIntoView({ behavior: "smooth", block: "start" }); };
  const p = report?.companyProfile || {};
  const fin = report?.financials || {};
  const ratios = fin.ratios || {};
  const [expandedDirector, setExpandedDirector] = useState(null);

  if (!report) return null;

  const badgeCount = (id) => {
    const m = { charges: report.charges, legalHistory: report.legalHistory, defaults: report.defaulterList, risk: report.riskFlags, gst: report.gst, directors: report.directors, dirNetwork: report.directorNetwork, securities: report.securitiesAllotment };
    return m[id]?.length || 0;
  };

  return (
    <div className="flex border border-slate-200 rounded-2xl overflow-hidden bg-white" style={{ minHeight: 600 }}>
      {/* Sidebar */}
      <nav className="w-52 shrink-0 border-r border-slate-200 bg-slate-50/80 hidden lg:block">
        <div className="sticky top-0 py-4 space-y-0.5 px-3" style={{ maxHeight: "80vh", overflowY: "auto" }}>
          {DATA_SECTIONS.map(({ id, label, icon: Icon }) => {
            const bc = badgeCount(id);
            return (
              <button key={id} onClick={() => scrollToSection(id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors ${activeSection === id ? "bg-blue-600 text-white font-medium shadow-sm" : "text-slate-600 hover:bg-slate-200/60 hover:text-slate-900"}`}>
                <Icon className="w-4 h-4 shrink-0" /> <span className="flex-1 text-left">{label}</span>
                {bc > 0 && <span className={`text-xs ${activeSection === id ? "text-blue-200" : "text-slate-400"}`}>{bc}</span>}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile horizontal nav */}
      <div className="lg:hidden flex gap-1 px-4 py-2 border-b border-slate-200 overflow-x-auto bg-slate-50 w-full">
        {DATA_SECTIONS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => scrollToSection(id)}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs whitespace-nowrap ${activeSection === id ? "bg-blue-600 text-white" : "text-slate-500 bg-slate-100"}`}>
            <Icon className="w-3 h-3" /> {label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 overflow-y-auto p-6 space-y-10" style={{ maxHeight: "80vh" }}>

        {/* ── Overview ── */}
        <section ref={el => { sectionRefs.current.overview = el; }}>
          <SectionHead icon={Building2} title="Company Overview" />
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
            <StatCard label="Status" value={p.efilingStatus || p.status || "—"} />
            <StatCard label="Compliance" value={p.activeCompliance || "—"} />
            <StatCard label="Authorized Capital" value={fmtCr(p.authorizedCapital)} />
            <StatCard label="Paid-up Capital" value={fmtCr(p.paidUpCapital)} />
          </div>
          {p.description && <p className="text-sm text-slate-600 leading-relaxed mb-5 bg-slate-50 p-4 rounded-xl border border-slate-100">{p.description}</p>}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <KV label="CIN" value={p.cin} mono /><KV label="Classification" value={p.companyType} />
            <KV label="Incorporated" value={p.dateOfIncorporation} /><KV label="PAN" value={p.pan} mono />
            <KV label="Registered Office" value={p.registeredOffice} />
            <KV label="Sum of Charges" value={fmtCr(p.sumOfCharges)} />
            {p.email && <KV label="Email" value={p.email} />}{p.website && <KV label="Website" value={p.website} />}
            <KV label="Last AGM" value={p.lastAgmDate} /><KV label="Last Filing" value={p.lastFilingDate} />
            {p.lei && <KV label="LEI" value={`${p.lei.number || "N/A"} (${p.lei.status || "N/A"})`} mono />}
          </div>
          {report.nameHistory?.length > 0 && <div className="mt-5"><h3 className="font-semibold text-slate-800 mb-3">Name History</h3>
            <div className="border border-slate-200 rounded-xl overflow-hidden"><table className="w-full text-sm"><tbody className="divide-y divide-slate-100">
              {report.nameHistory.map((n, i) => <tr key={i}><td className="px-4 py-2.5 font-medium">{n.name}</td><td className="px-4 py-2.5 text-slate-500">{n.date}</td></tr>)}
            </tbody></table></div></div>}
          {report.industrySegments?.length > 0 && <div className="mt-5"><h3 className="font-semibold text-slate-800 mb-3">Industry Segments</h3>
            <div className="flex flex-wrap gap-2">{report.industrySegments.map((seg, i) => <span key={i} className="px-3 py-1.5 bg-blue-50 text-blue-700 text-xs font-medium rounded-full border border-blue-100">{seg.industry}{seg.segments?.length > 0 ? ` — ${seg.segments.join(", ")}` : ""}</span>)}</div></div>}
          {report.probeScore && <div className="mt-5"><h3 className="font-semibold text-slate-800 mb-3">Probe Financial Score</h3>
            <div className="grid grid-cols-3 lg:grid-cols-6 gap-2">
              {[["Overall", report.probeScore.overall], ["Growth", report.probeScore.growth], ["Profitability", report.probeScore.profitability],
                ["Liquidity", report.probeScore.liquidity], ["Solvency", report.probeScore.solvency], ["Efficiency", report.probeScore.efficiency]
              ].map(([l, v]) => <div key={l} className="text-center p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className={`text-2xl font-bold ${v >= 4 ? "text-emerald-600" : v >= 3 ? "text-amber-600" : "text-red-600"}`}>{v || 0}/5</div>
                <div className="text-xs text-slate-500 mt-1">{l}</div></div>)}
            </div></div>}
        </section>

        {/* ── Directors ── */}
        <section ref={el => { sectionRefs.current.directors = el; }}>
          <SectionHead icon={Users} title="Directors & Signatories" count={report.directors?.length} />
          {report.directors?.length > 0 ? <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200"><tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Name</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">DIN</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Designation</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Appointed</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">DIN Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Status</th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              {report.directors.map((d, i) => <tr key={i} className="hover:bg-slate-50">
                <td className="px-4 py-3"><div className="font-medium">{d.name}</div>{d.nationality && d.nationality !== "India" && <span className="text-xs text-slate-400">{d.nationality}</span>}</td>
                <td className="px-4 py-3 font-mono text-xs text-slate-500">{d.din || "—"}</td>
                <td className="px-4 py-3 text-slate-600">{d.designation}</td>
                <td className="px-4 py-3 text-slate-500 text-xs">{d.dateOfAppointment}</td>
                <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${d.dinStatus?.toLowerCase()?.includes("disqualified") ? "bg-red-50 text-red-700" : d.dinStatus?.toLowerCase()?.includes("deactivated") ? "bg-amber-50 text-amber-700" : "bg-slate-50 text-slate-500"}`}>{d.dinStatus || "—"}</span></td>
                <td className="px-4 py-3"><span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${d.isActive ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{d.isActive ? "Active" : `Ceased ${d.dateOfCessation || ""}`}</span></td>
              </tr>)}
            </tbody></table></div> : <p className="text-slate-400 text-sm">No director data.</p>}
        </section>

        {/* ── Director Network ── */}
        <section ref={el => { sectionRefs.current.dirNetwork = el; }}>
          <SectionHead icon={Network} title="Director Network" count={report.directorNetwork?.length} />
          {report.directorNetwork?.length > 0 ? <div className="space-y-3">
            <ShowMore items={report.directorNetwork} initialCount={5} label="directors" renderItem={(dn, i) => (
              <div key={i} className="border border-slate-200 rounded-xl overflow-hidden">
                <button onClick={() => setExpandedDirector(expandedDirector === i ? null : i)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-white hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3"><Users className="w-4 h-4 text-slate-400" />
                    <div className="text-left"><p className="font-medium text-sm">{dn.name}</p><p className="text-xs text-slate-400">DIN: {dn.din} · {dn.totalAssociations} associations</p></div>
                  </div>
                  {expandedDirector === i ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                </button>
                {expandedDirector === i && dn.companies?.length > 0 && <div className="border-t border-slate-100 max-h-60 overflow-y-auto">
                  <table className="w-full text-xs"><thead className="bg-slate-50 sticky top-0"><tr>
                    <th className="px-3 py-2 text-left font-semibold text-slate-500">Company</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-500">Designation</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-500">Status</th>
                  </tr></thead><tbody className="divide-y divide-slate-50">
                    {dn.companies.map((c, j) => <tr key={j}><td className="px-3 py-2"><div className="font-medium">{c.name}</div><span className="text-slate-400 font-mono">{c.cin}</span></td>
                      <td className="px-3 py-2 text-slate-600">{c.designation}</td>
                      <td className="px-3 py-2"><span className={`px-1.5 py-0.5 rounded text-xs ${c.status?.includes("ACTIVE") ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-600"}`}>{c.status}</span></td></tr>)}
                  </tbody></table></div>}
              </div>
            )} />
          </div> : <p className="text-slate-400 text-sm">No network data.</p>}
        </section>

        {/* ── Financials ── */}
        <section ref={el => { sectionRefs.current.financials = el; }}>
          <SectionHead icon={BarChart3} title="Financials" />
          {fin.latestYear ? <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
              <StatCard label="Revenue" value={fmtCr(fin.revenue)} sub={`FY ${fin.latestYear}`} />
              <StatCard label="Net Profit" value={fmtCr(fin.profit)} sub={`FY ${fin.latestYear}`} />
              <StatCard label="Net Worth" value={fmtCr(fin.netWorth)} sub={`FY ${fin.latestYear}`} />
              <StatCard label="Total Assets" value={fmtCr(fin.totalAssets)} sub={`FY ${fin.latestYear}`} />
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
              <StatCard label="EBITDA" value={fmtCr(fin.ebitda)} /><StatCard label="Total Debt" value={fmtCr(fin.totalDebt)} />
              <StatCard label="Cash & Bank" value={fmtCr(fin.cashAndBank)} /><StatCard label="Interest" value={fmtCr(fin.interest)} />
            </div>
            <h3 className="font-semibold text-slate-800 mb-3">Key Ratios</h3>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1 bg-white rounded-xl border border-slate-200 p-5 mb-5">
              <KV label="Revenue Growth" value={fmtPct(ratios.revenueGrowth)} /><KV label="Net Margin" value={fmtPct(ratios.netMargin)} />
              <KV label="EBITDA Margin" value={fmtPct(ratios.ebitdaMargin)} /><KV label="ROE" value={fmtPct(ratios.returnOnEquity)} />
              <KV label="ROCE" value={fmtPct(ratios.returnOnCapitalEmployed)} /><KV label="Current Ratio" value={ratios.currentRatio?.toFixed(2) || "—"} />
              <KV label="Quick Ratio" value={ratios.quickRatio?.toFixed(2) || "—"} /><KV label="Interest Coverage" value={ratios.interestCoverageRatio?.toFixed(2) || "—"} />
              <KV label="D/E Ratio" value={ratios.debtByEquity != null ? `${ratios.debtByEquity.toFixed(2)}x` : "—"} />
              <KV label="Debtor Days" value={ratios.debtorDays?.toFixed(0) || "—"} /><KV label="Payable Days" value={ratios.payableDays?.toFixed(0) || "—"} />
              <KV label="Cash Cycle" value={ratios.cashConversionCycle?.toFixed(0) || "—"} />
            </div>
            {fin.history?.length > 0 && <><h3 className="font-semibold text-slate-800 mb-3">Financial History</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm">
                <thead className="bg-slate-50 border-b"><tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Year</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Revenue</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Profit</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Net Worth</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Debt</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Growth</th>
                </tr></thead><tbody className="divide-y divide-slate-100">
                  {fin.history.map((h, i) => <tr key={i} className="hover:bg-slate-50">
                    <td className="px-4 py-2.5 font-medium">{h.year}</td>
                    <td className="px-4 py-2.5 text-right">{fmtCr(h.revenue)}</td><td className="px-4 py-2.5 text-right">{fmtCr(h.profit)}</td>
                    <td className="px-4 py-2.5 text-right">{fmtCr(h.netWorth)}</td><td className="px-4 py-2.5 text-right">{fmtCr(h.totalDebt)}</td>
                    <td className={`px-4 py-2.5 text-right font-medium ${h.revenueGrowth >= 0 ? "text-emerald-600" : "text-red-600"}`}>{fmtPct(h.revenueGrowth)}</td>
                  </tr>)}
                </tbody></table></div></>}
          </> : <p className="text-slate-400 text-sm">No financial data available.</p>}
        </section>

        {/* ── Charges ── */}
        <section ref={el => { sectionRefs.current.charges = el; }}>
          <SectionHead icon={Landmark} title="Charges" count={report.charges?.length} />
          {report.charges?.length > 0 ? <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm">
            <thead className="bg-slate-50 border-b"><tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Charge Holder</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Type</th>
            </tr></thead><tbody className="divide-y divide-slate-100">
              <ShowMore items={report.charges} initialCount={15} label="charges" renderItem={(c, i) => (
                <tr key={i}><td className="px-4 py-2.5 font-medium text-xs">{c.chargeHolder}</td>
                  <td className="px-4 py-2.5 text-right font-semibold">{fmtCr(c.amount)}</td>
                  <td className="px-4 py-2.5 text-slate-500 text-xs">{c.dateOfCreation}</td>
                  <td className="px-4 py-2.5"><span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${c.type === "Creation" ? "bg-blue-50 text-blue-700" : "bg-amber-50 text-amber-700"}`}>{c.type}</span></td>
                </tr>
              )} />
            </tbody></table></div> : <p className="text-slate-400 text-sm">No open charges.</p>}
        </section>

        {/* ── Legal History ── */}
        <section ref={el => { sectionRefs.current.legalHistory = el; }}>
          <SectionHead icon={Gavel} title="Legal History" count={report.legalHistory?.length} />
          {report.legalHistory?.length > 0 ? <>
            {(() => {
              const against = report.legalHistory.filter(c => c.caseType?.includes("Against"));
              const byThisCorp = report.legalHistory.filter(c => c.caseType?.includes("By This"));
              const pending = report.legalHistory.filter(c => c.caseStatus === "Pending");
              return <div className="grid grid-cols-3 gap-3 mb-4">
                <StatCard label="Total Cases" value={report.legalHistory.length} />
                <StatCard label="Pending" value={pending.length} />
                <StatCard label="Against Company" value={against.length} />
              </div>;
            })()}
            <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-xs">
              <thead className="bg-slate-50 border-b sticky top-0"><tr>
                <th className="px-3 py-2.5 text-left font-semibold text-slate-500">Case</th>
                <th className="px-3 py-2.5 text-left font-semibold text-slate-500">Court</th>
                <th className="px-3 py-2.5 text-left font-semibold text-slate-500">Category</th>
                <th className="px-3 py-2.5 text-left font-semibold text-slate-500">Status</th>
                <th className="px-3 py-2.5 text-left font-semibold text-slate-500">Severity</th>
              </tr></thead><tbody className="divide-y divide-slate-100">
                <ShowMore items={report.legalHistory} initialCount={15} label="cases" renderItem={(c, i) => (
                  <tr key={i} className="hover:bg-slate-50"><td className="px-3 py-2"><div className="font-mono text-[10px] text-slate-400">{c.caseNumber}</div><div className="text-slate-600 mt-0.5 max-w-xs truncate">{c.petitioner?.substring(0, 40)}</div></td>
                    <td className="px-3 py-2 text-slate-600 max-w-[150px] truncate">{c.court}</td>
                    <td className="px-3 py-2 text-slate-500">{c.caseCategory}</td>
                    <td className="px-3 py-2"><span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${c.caseStatus === "Pending" ? "bg-amber-50 text-amber-700" : "bg-slate-50 text-slate-500"}`}>{c.caseStatus}</span></td>
                    <td className="px-3 py-2"><SevBadge severity={c.severity} /></td></tr>
                )} />
              </tbody></table></div>
          </> : <p className="text-slate-400 text-sm">No legal history.</p>}
        </section>

        {/* ── Defaults & Credit ── */}
        <section ref={el => { sectionRefs.current.defaults = el; }}>
          <SectionHead icon={BadgeAlert} title="Defaults & Credit Ratings" />
          {report.cdrHistory?.length > 0 && <div className="mb-5"><h3 className="font-semibold text-slate-800 mb-2">CDR History</h3>
            {report.cdrHistory.map((c, i) => <div key={i} className="p-3 bg-amber-50 border border-amber-100 rounded-lg text-sm mb-2"><span className="font-medium text-amber-800">{c.date}</span> — <span className="text-amber-700">{c.description}</span></div>)}</div>}
          {report.creditRatings?.length > 0 && <div className="mb-5"><h3 className="font-semibold text-slate-800 mb-3">Credit Ratings</h3>
            <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm"><thead className="bg-slate-50 border-b"><tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Agency</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Rating</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Loan Type</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Amount</th>
            </tr></thead><tbody className="divide-y divide-slate-100">
              {report.creditRatings.map((r, i) => <tr key={i}><td className="px-4 py-2.5 text-slate-500">{r.ratingDate}</td>
                <td className="px-4 py-2.5 uppercase font-semibold text-xs">{r.agency}</td>
                <td className="px-4 py-2.5"><span className={`px-2 py-0.5 rounded text-xs font-bold ${r.rating?.includes("D") ? "bg-red-100 text-red-700" : r.rating?.includes("NM") ? "bg-slate-100 text-slate-600" : "bg-emerald-50 text-emerald-700"}`}>{r.rating}</span></td>
                <td className="px-4 py-2.5 text-xs text-slate-600">{r.loanType}</td>
                <td className="px-4 py-2.5 text-right">{fmtCr(r.amount)}</td></tr>)}
            </tbody></table></div></div>}
          {report.defaulterList?.length > 0 && <div><h3 className="font-semibold text-slate-800 mb-3">Defaulter List <span className="text-sm font-normal text-slate-400">({report.defaulterList.length} entries)</span></h3>
            {(() => {
              const latest = {};
              report.defaulterList.forEach(d => { const k = `${d.bank}-${d.defaulterType}`; if (!latest[k] || d.date > latest[k].date) latest[k] = d; });
              const unique = Object.values(latest).sort((a, b) => b.amount - a.amount);
              return <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm"><thead className="bg-slate-50 border-b"><tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Bank</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Amount</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Type</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">As of</th>
              </tr></thead><tbody className="divide-y divide-slate-100">
                <ShowMore items={unique} initialCount={15} label="entries" renderItem={(d, i) => (
                  <tr key={i}><td className="px-4 py-2.5 font-medium text-xs">{d.bank}</td>
                    <td className="px-4 py-2.5 text-right font-semibold">{fmtCr(d.amount)}</td>
                    <td className="px-4 py-2.5"><span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${d.defaulterType?.includes("Wilful") ? "bg-red-100 text-red-700" : "bg-amber-50 text-amber-700"}`}>{d.defaulterType}</span></td>
                    <td className="px-4 py-2.5 text-slate-500 text-xs">{d.date}</td></tr>
                )} />
              </tbody></table></div>;
            })()}</div>}
          {!report.defaulterList?.length && !report.creditRatings?.length && <p className="text-slate-400 text-sm">No default or credit rating data.</p>}
        </section>

        {/* ── Risk Flags ── */}
        <section ref={el => { sectionRefs.current.risk = el; }}>
          <SectionHead icon={AlertTriangle} title="Risk Flags" count={report.riskFlags?.length} />
          {report.riskFlags?.length > 0 ? <div className="space-y-3">
            {report.riskFlags.map((r, i) => <div key={i} className="p-4 rounded-xl border border-slate-200 bg-white flex items-start justify-between gap-3">
              <div><div className="flex items-center gap-2 mb-1"><span className="font-medium text-sm">{r.type}</span><SevBadge severity={r.severity} /></div>
                <p className="text-sm text-slate-500">{r.description}</p></div></div>)}
          </div> : <div className="text-center py-8 border border-slate-200 rounded-xl">
            <Shield className="w-8 h-8 mx-auto text-emerald-500 mb-2" /><p className="font-medium text-slate-700">No risk flags detected</p></div>}
        </section>

        {/* ── GST ── */}
        <section ref={el => { sectionRefs.current.gst = el; }}>
          <SectionHead icon={Scale} title="GST Registrations" count={report.gst?.length} />
          {report.gst?.length > 0 ? <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm"><thead className="bg-slate-50 border-b"><tr>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">GSTIN</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Trade Name</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">State</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Registered</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Status</th>
          </tr></thead><tbody className="divide-y divide-slate-100">
            {report.gst.map((g, i) => <tr key={i}><td className="px-4 py-2.5 font-mono text-xs">{g.gstin}</td>
              <td className="px-4 py-2.5 text-sm">{g.tradeName}</td><td className="px-4 py-2.5">{g.state}</td>
              <td className="px-4 py-2.5 text-slate-500">{g.registrationDate}</td>
              <td className="px-4 py-2.5"><span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${g.status === "Active" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>{g.status}</span></td></tr>)}
          </tbody></table></div> : <p className="text-slate-400 text-sm">No GST registrations.</p>}
        </section>

        {/* ── Shareholding ── */}
        <section ref={el => { sectionRefs.current.shareholding = el; }}>
          <SectionHead icon={PieChart} title="Shareholding Pattern" count={report.shareholding?.length} />
          {report.shareholding?.length > 0 ? <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm"><thead className="bg-slate-50 border-b"><tr>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Shareholder</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Category</th>
            <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Holding</th>
          </tr></thead><tbody className="divide-y divide-slate-100">
            {report.shareholding.map((s, i) => <tr key={i}><td className="px-4 py-2.5 font-medium">{s.name}</td>
              <td className="px-4 py-2.5 text-slate-500">{s.category}</td>
              <td className="px-4 py-2.5 text-right"><div className="flex items-center justify-end gap-2">
                <div className="w-20 h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full rounded-full bg-blue-600" style={{ width: `${Math.min(s.percentage, 100)}%` }} /></div>
                <span className="font-mono text-sm w-14 text-right font-semibold">{s.percentage?.toFixed(1)}%</span></div></td></tr>)}
          </tbody></table></div> : <p className="text-slate-400 text-sm">No shareholding data.</p>}
        </section>

        {/* ── Securities Allotment ── */}
        <section ref={el => { sectionRefs.current.securities = el; }}>
          <SectionHead icon={CreditCard} title="Securities Allotment" count={report.securitiesAllotment?.length} />
          {report.securitiesAllotment?.length > 0 ? <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm"><thead className="bg-slate-50 border-b"><tr>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Date</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Instrument</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Type</th>
            <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Securities</th>
            <th className="px-4 py-3 text-right text-xs font-semibold text-slate-500">Amount Raised</th>
          </tr></thead><tbody className="divide-y divide-slate-100">
            {report.securitiesAllotment.map((s, i) => <tr key={i}><td className="px-4 py-2.5 text-slate-500">{s.allotmentDate}</td>
              <td className="px-4 py-2.5 font-medium text-xs">{s.instrument}</td><td className="px-4 py-2.5">{s.allotmentType}</td>
              <td className="px-4 py-2.5 text-right font-mono">{s.numberOfSecurities?.toLocaleString()}</td>
              <td className="px-4 py-2.5 text-right font-semibold">{fmtCr(s.totalAmountRaised)}</td></tr>)}
          </tbody></table></div> : <p className="text-slate-400 text-sm">No securities data.</p>}
        </section>

        {/* ── EPFO ── */}
        <section ref={el => { sectionRefs.current.epfo = el; }}>
          <SectionHead icon={Briefcase} title="EPFO Establishments" count={report.epfo?.length} />
          {report.epfo?.length > 0 ? <div className="space-y-3">
            {report.epfo.map((e, i) => <div key={i} className="p-4 rounded-xl border border-slate-200 bg-white">
              <div className="flex items-center gap-2 mb-2"><span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${e.workingStatus === "LIVE ESTABLISHMENT" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>{e.workingStatus}</span></div>
              <p className="font-medium text-sm">{e.name}</p><p className="text-xs font-mono text-slate-400 mt-1">{e.establishmentId}</p>
              {e.address && <p className="text-xs text-slate-500 mt-1">{e.address}</p>}
            </div>)}
          </div> : <p className="text-slate-400 text-sm">No EPFO data.</p>}
        </section>

        {/* ── Addresses ── */}
        <section ref={el => { sectionRefs.current.addresses = el; }}>
          <SectionHead icon={MapPin} title="Addresses" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {report.addresses?.map((a, i) => <div key={i} className="p-4 rounded-xl border border-slate-200 bg-white">
              <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded mb-2 inline-block">{a.type}</span>
              <p className="text-sm text-slate-700">{a.line1}</p>{a.line2 && <p className="text-sm text-slate-600">{a.line2}</p>}
              <p className="text-sm text-slate-600">{a.city}, {a.state} — {a.pincode}</p></div>)}
            {(!report.addresses || report.addresses.length === 0) && <p className="text-slate-400 text-sm">No addresses.</p>}
          </div>
        </section>

        {/* ── Filings ── */}
        <section ref={el => { sectionRefs.current.filings = el; }}>
          <SectionHead icon={FileText} title="Recent Filings" />
          {report.filings?.length > 0 ? <div className="overflow-x-auto border border-slate-200 rounded-xl"><table className="w-full text-sm"><thead className="bg-slate-50 border-b"><tr>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Form</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Date</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500">Description</th>
          </tr></thead><tbody className="divide-y divide-slate-100">
            {report.filings.map((f, i) => <tr key={i}><td className="px-4 py-2.5 font-mono text-xs font-semibold">{f.formType}</td>
              <td className="px-4 py-2.5 text-slate-500">{f.dateOfFiling}</td><td className="px-4 py-2.5">{f.description}</td></tr>)}
          </tbody></table></div> : <p className="text-slate-400 text-sm">No filing data.</p>}
        </section>

        {/* ── Contact ── */}
        <section ref={el => { sectionRefs.current.contact = el; }} className="pb-8">
          <SectionHead icon={BookOpen} title="Contact Details" />
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            {report.contactDetails?.emails?.length > 0 && <div className="mb-4"><h4 className="text-xs font-semibold text-slate-400 uppercase mb-2">Email</h4>
              {report.contactDetails.emails.map((e, i) => <p key={i} className="text-sm text-blue-600">{e.email} {e.status && <span className="text-slate-400 text-xs">({e.status})</span>}</p>)}</div>}
            {report.contactDetails?.phones?.length > 0 && <div><h4 className="text-xs font-semibold text-slate-400 uppercase mb-2">Phone</h4>
              {report.contactDetails.phones.map((p, i) => <p key={i} className="text-sm text-slate-700">{p}</p>)}</div>}
            {(!report.contactDetails?.emails?.length && !report.contactDetails?.phones?.length) && <p className="text-slate-400 text-sm">No contact details available.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}

// ─── Workflow Step Badge ───
function StepBadge({ done, active, label }) {
  return <div className={`flex items-center gap-2 text-sm font-medium px-3 py-1.5 rounded-full ${done ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : active ? "bg-blue-50 text-blue-700 border border-blue-200" : "bg-slate-50 text-slate-400 border border-slate-200"}`}>
    {done ? <CheckCircle2 className="w-4 h-4" /> : <div className={`w-4 h-4 rounded-full border-2 ${active ? "border-blue-500" : "border-slate-300"}`} />}{label}
  </div>;
}

const RATING_COLORS = { "A+": "text-emerald-700 bg-emerald-50 border-emerald-300", A: "text-emerald-700 bg-emerald-50 border-emerald-300", "B+": "text-amber-700 bg-amber-50 border-amber-300", B: "text-amber-700 bg-amber-50 border-amber-300", C: "text-red-700 bg-red-50 border-red-300", D: "text-red-900 bg-red-100 border-red-400" };
const RISK_COLORS = { Low: "bg-emerald-50 border-emerald-200 text-emerald-700", Medium: "bg-amber-50 border-amber-200 text-amber-700", High: "bg-red-50 border-red-200 text-red-700", "Very High": "bg-red-100 border-red-300 text-red-900" };

// ─── Main Component ───
function OpsOrderDetail() {
  const routeParams = useParams();
  const id = Number(routeParams?.id);
  const queryClient = useQueryClient();
  const { data: order, isLoading } = useGetOperationsOrder(id);
  const fetchMut = useFetchComprehensiveReportData();
  const enrichMut = useSaveAnalystEnrichment();
  const modelMut = useRunDecisionModels();
  const pdfMut = useGeneratePdfReport();
  const publishMut = usePublishOrder();
  const [activeTab, setActiveTab] = useState("data");
  const [investigationSummary, setInvestigationSummary] = useState("");
  const [analystComments, setAnalystComments] = useState("");
  const [recommendationNotes, setRecommendationNotes] = useState("");
  const [redFlags, setRedFlags] = useState([]);
  const [newFlag, setNewFlag] = useState("");
  const [toastMsg, setToastMsg] = useState(null);
  const [localReport, setLocalReport] = useState(null);
  const [localDecision, setLocalDecision] = useState(null);

  useEffect(() => {
    if (order?.analystEnrichment) {
      setInvestigationSummary(order.analystEnrichment.investigationSummary || "");
      setAnalystComments(order.analystEnrichment.analystComments || "");
      setRecommendationNotes(order.analystEnrichment.recommendationNotes || "");
      setRedFlags(order.analystEnrichment.redFlags || []);
      if (order.analystEnrichment.decisionOutputs) setLocalDecision(order.analystEnrichment.decisionOutputs);
    }
    if (order?.providerSearchSnapshot?.rawResults) setLocalReport(order.providerSearchSnapshot.rawResults);
  }, [order]);

  const toast = (type, text) => { setToastMsg({ type, text }); setTimeout(() => setToastMsg(null), 3500); };
  const invalidate = () => queryClient.invalidateQueries({ queryKey: [`opsOrder-${id}`] });

  if (!id || isNaN(id)) return <div className="p-8 text-center text-red-500">Invalid order ID. <Link href="~/operations/orders" className="text-blue-600 underline">Back to Queue</Link></div>;
  if (isLoading) return <div className="flex flex-col items-center justify-center py-24 text-slate-400"><Loader2 className="w-10 h-10 animate-spin mb-4" />Loading order...</div>;
  if (!order) return <div className="p-8 text-center text-red-500">Order not found. <Link href="~/operations/orders" className="text-blue-600 underline">Back to Queue</Link></div>;

  const hasData = !!(order.providerSearchSnapshot || localReport);
  const hasModels = !!(localDecision || order.analystEnrichment?.decisionOutputs);
  const hasPdf = order.generatedDocuments?.some(d => d.documentType === "due_diligence_report" && d.status === "ready");
  const isCompleted = order.status === "completed";
  const report = localReport || order.providerSearchSnapshot?.rawResults;
  const decision = localDecision || order.analystEnrichment?.decisionOutputs;

  const handleFetchData = () => { fetchMut.mutate({ id }, { onSuccess: (d) => { setLocalReport(d.report); invalidate(); toast("success", "Data fetched"); }, onError: () => toast("error", "Fetch failed") }); };
  const handleSaveEnrichment = (isDraft) => { enrichMut.mutate({ id, data: { investigationSummary, analystComments, redFlags, recommendationNotes, isDraft } }, { onSuccess: () => { invalidate(); toast("success", isDraft ? "Draft saved" : "Notes submitted"); }, onError: () => toast("error", "Save failed") }); };
  const handleRunModels = () => { modelMut.mutate({ id }, { onSuccess: (d) => { setLocalDecision(d); invalidate(); toast("success", "Models executed"); setActiveTab("decision"); }, onError: (e) => toast("error", e?.message || "Failed") }); };
  const handleGeneratePdf = () => { pdfMut.mutate({ id }, { onSuccess: () => { invalidate(); toast("success", "PDF generated"); setActiveTab("publish"); }, onError: (e) => toast("error", e?.message || "Failed") }); };
  const handlePublish = () => { publishMut.mutate({ id }, { onSuccess: () => { invalidate(); toast("success", "Published!"); }, onError: (e) => toast("error", e?.message || "Failed") }); };

  const TABS = [{ id: "data", label: "Company Data", icon: Building2 }, { id: "notes", label: "Analyst Notes", icon: FileText }, { id: "decision", label: "Decision Engine", icon: TrendingUp }, { id: "publish", label: "Publish", icon: Send }];

  return (
    <div className="pb-16 relative">
      {toastMsg && <div className={`fixed top-6 right-6 z-50 px-5 py-3 rounded-2xl shadow-xl font-medium text-sm flex items-center gap-2 ${toastMsg.type === "success" ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
        {toastMsg.type === "success" ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}{toastMsg.text}
      </div>}

      <div className="mb-6"><Link href="~/operations/orders" className="text-slate-500 hover:text-slate-900 inline-flex items-center text-sm font-medium transition-colors"><ArrowLeft className="w-4 h-4 mr-1" /> Back to Queue</Link></div>

      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-3 flex-wrap mb-1">
            <h1 className="text-2xl font-bold text-slate-900">{order.subjectName}</h1>
            <StatusBadge status={order.status} /><PriorityBadge priority={order.priority} />
          </div>
          <p className="text-slate-500 text-sm">{order.orderNumber} &bull; {order.clientCompanyName || "—"} &bull; {order.productName || "DDR"} &bull; Submitted {formatDate(order.createdAt)}</p>
          {order.subjectDetails?.cin && <p className="text-xs font-mono text-slate-400 mt-1">CIN: {order.subjectDetails.cin}</p>}
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-8">
        <StepBadge done={hasData} active={!hasData} label="Data Fetched" />
        <StepBadge done={!!order.analystEnrichment?.investigationSummary} active={hasData && !order.analystEnrichment?.investigationSummary} label="Notes Written" />
        <StepBadge done={hasModels} active={!!order.analystEnrichment?.investigationSummary && !hasModels} label="Models Run" />
        <StepBadge done={hasPdf} active={hasModels && !hasPdf} label="PDF Generated" />
        <StepBadge done={isCompleted} active={hasPdf && !isCompleted} label="Published" />
      </div>

      <div className="flex gap-1 border-b border-slate-200 mb-8 overflow-x-auto">
        {TABS.map(tab => <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 -mb-px transition-colors whitespace-nowrap ${activeTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-slate-500 hover:text-slate-900"}`}><tab.icon className="w-4 h-4" />{tab.label}</button>)}
      </div>

      {/* Company Data Tab */}
      {activeTab === "data" && (
        <div className="space-y-5">
          {!hasData ? (
            <Card className="p-12 text-center">
              <Building2 className="w-14 h-14 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-700 mb-2">No Data Fetched Yet</h3>
              <p className="text-slate-500 text-sm mb-6">Fetch comprehensive company data from the registry.</p>
              <Button size="lg" onClick={handleFetchData} isLoading={fetchMut.isPending}><RefreshCw className="w-4 h-4 mr-2" /> Fetch Company Data</Button>
            </Card>
          ) : (<>
            <div className="flex justify-end"><Button variant="outline" size="sm" onClick={handleFetchData} isLoading={fetchMut.isPending}><RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Re-fetch</Button></div>
            <CompanyDataPanel report={report} />
            <div className="flex justify-end pt-4"><Button onClick={() => setActiveTab("notes")} size="lg">Continue to Analyst Notes →</Button></div>
          </>)}
        </div>
      )}

      {/* Analyst Notes Tab */}
      {activeTab === "notes" && (
        <div className="space-y-6">
          {!hasData && <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-sm font-medium"><AlertTriangle className="w-4 h-4" /> Fetch company data first before writing notes.</div>}
          <Card className="p-6"><h3 className="font-bold text-slate-800 mb-5 flex items-center gap-2"><FileText className="w-4 h-4 text-blue-600" /> Investigation</h3>
            <div className="space-y-5"><div><Label>Investigation Summary *</Label><Textarea value={investigationSummary} onChange={e => setInvestigationSummary(e.target.value)} className="h-36" placeholder="Summarize key findings from the company data..." /></div>
              <div><Label>Analyst Comments</Label><Textarea value={analystComments} onChange={e => setAnalystComments(e.target.value)} className="h-28" placeholder="Additional observations..." /></div></div>
          </Card>
          <Card className="p-6"><h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-red-500" /> Red Flags</h3>
            <div className="space-y-2 mb-4">{redFlags.length === 0 && <p className="text-slate-400 text-sm italic">No red flags added yet.</p>}
              {redFlags.map((f, i) => <div key={i} className="flex items-center gap-2 bg-red-50 border border-red-100 rounded-lg px-4 py-2.5 text-sm text-red-700"><AlertTriangle className="w-3.5 h-3.5" /><span className="flex-1">{f}</span><button onClick={() => setRedFlags(fs => fs.filter((_, j) => j !== i))} className="text-red-400 hover:text-red-700"><X className="w-3.5 h-3.5" /></button></div>)}
            </div>
            <div className="flex gap-2"><Input placeholder="Add red flag..." value={newFlag} onChange={e => setNewFlag(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && newFlag.trim()) { setRedFlags(fs => [...fs, newFlag.trim()]); setNewFlag(""); } }} /><Button variant="outline" size="md" onClick={() => { if (newFlag.trim()) { setRedFlags(fs => [...fs, newFlag.trim()]); setNewFlag(""); } }}><Plus className="w-4 h-4" /></Button></div>
          </Card>
          <Card className="p-6"><h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Shield className="w-4 h-4 text-blue-600" /> Recommendation</h3>
            <Textarea value={recommendationNotes} onChange={e => setRecommendationNotes(e.target.value)} className="h-28" placeholder="Final recommendation and rationale..." /></Card>
          <div className="flex justify-between items-center pt-2">
            <Button variant="outline" onClick={() => handleSaveEnrichment(true)} isLoading={enrichMut.isPending}><Save className="w-4 h-4 mr-2" /> Save Draft</Button>
            <div className="flex gap-3"><Button variant="secondary" onClick={() => handleSaveEnrichment(false)} isLoading={enrichMut.isPending} disabled={!investigationSummary.trim()}>Submit Notes</Button><Button onClick={() => setActiveTab("decision")}>Decision Engine →</Button></div>
          </div>
        </div>
      )}

      {/* Decision Engine Tab */}
      {activeTab === "decision" && (
        <div className="space-y-6">
          {!hasModels ? (
            <Card className="p-12 text-center"><TrendingUp className="w-14 h-14 text-slate-300 mx-auto mb-4" /><h3 className="text-lg font-bold text-slate-700 mb-2">Run Decision Engine</h3><p className="text-slate-500 text-sm mb-6">Execute scoring models on the fetched data.</p>
              <Button size="lg" onClick={handleRunModels} isLoading={modelMut.isPending} disabled={!hasData}><Play className="w-4 h-4 mr-2" /> Run Models</Button>
              {!hasData && <p className="text-xs text-amber-600 mt-3">Fetch data first.</p>}</Card>
          ) : (<>
            <div className="flex justify-end"><Button variant="outline" size="sm" onClick={handleRunModels} isLoading={modelMut.isPending}><RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Re-run</Button></div>
            {decision && <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="p-6"><h4 className="text-xs font-semibold text-slate-400 uppercase mb-3">Credit Rating</h4><div className={`inline-flex items-center px-4 py-2 rounded-xl border-2 text-2xl font-bold ${RATING_COLORS[decision.creditRating?.rating] || "text-slate-700 bg-slate-50 border-slate-300"}`}>{decision.creditRating?.rating || "N/A"}</div><p className="text-sm text-slate-500 mt-3">{decision.creditRating?.rationale}</p></Card>
              <Card className="p-6"><h4 className="text-xs font-semibold text-slate-400 uppercase mb-3">Risk Score</h4><div className="text-3xl font-bold text-slate-900">{decision.riskScore?.score}<span className="text-base text-slate-400 font-normal"> / 100</span></div><div className={`inline-flex mt-2 px-3 py-1 rounded-full text-xs font-semibold border ${RISK_COLORS[decision.riskScore?.band] || "bg-slate-50 border-slate-200 text-slate-600"}`}>{decision.riskScore?.band || "Unknown"}</div></Card>
              <Card className="p-6"><h4 className="text-xs font-semibold text-slate-400 uppercase mb-3">Eligibility</h4><div className="text-lg font-bold">{decision.eligibility ? `${fmtCr(decision.eligibility.recommendedAmountMin || 0)} - ${fmtCr(decision.eligibility.recommendedAmountMax || 0)}` : "N/A"}</div></Card>
            </div>}
            {decision?.keyRiskDrivers?.length > 0 && <Card className="p-6"><h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-amber-500" /> Key Risk Drivers</h4><div className="space-y-2">{decision.keyRiskDrivers.map((d, i) => <div key={i} className="flex items-start gap-2 text-sm text-slate-700 bg-amber-50 rounded-lg p-3 border border-amber-100"><AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />{d}</div>)}</div></Card>}
            <div className="flex justify-end pt-4"><Button onClick={() => setActiveTab("publish")} size="lg">Continue to Publish →</Button></div>
          </>)}
        </div>
      )}

      {/* Publish Tab */}
      {activeTab === "publish" && (
        <div className="space-y-6"><Card className="p-8"><h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2"><FileOutput className="w-5 h-5 text-blue-600" /> Generate & Publish</h3>
          <div className="space-y-4">
            <div className={`p-5 rounded-xl border ${hasPdf ? "border-emerald-200 bg-emerald-50" : "border-slate-200 bg-slate-50"}`}><div className="flex items-center justify-between"><div className="flex items-center gap-3">{hasPdf ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <FileOutput className="w-5 h-5 text-slate-400" />}<div><p className="font-semibold text-slate-800">Generate PDF Report</p><p className="text-xs text-slate-500 mt-0.5">{hasPdf ? "PDF ready for download" : "Create the due diligence report PDF"}</p></div></div><Button variant={hasPdf ? "outline" : "primary"} size="sm" onClick={handleGeneratePdf} isLoading={pdfMut.isPending} disabled={!hasData}>{hasPdf ? "Re-generate" : "Generate"}</Button></div></div>
            <div className={`p-5 rounded-xl border ${isCompleted ? "border-emerald-200 bg-emerald-50" : "border-slate-200 bg-slate-50"}`}><div className="flex items-center justify-between"><div className="flex items-center gap-3">{isCompleted ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <Send className="w-5 h-5 text-slate-400" />}<div><p className="font-semibold text-slate-800">Publish to Client</p><p className="text-xs text-slate-500 mt-0.5">{isCompleted ? "Report published and available to client" : "Make the report available to the client"}</p></div></div>{!isCompleted && <Button size="sm" onClick={handlePublish} isLoading={publishMut.isPending} disabled={!hasPdf}><Send className="w-4 h-4 mr-1.5" /> Publish</Button>}</div></div>
          </div>
          {isCompleted && <div className="mt-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center"><CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" /><p className="font-bold text-emerald-800">Report Published!</p><p className="text-sm text-emerald-600 mt-1">Client has been notified and can now download the report.</p></div>}
        </Card></div>
      )}
    </div>
  );
}

export default OpsOrderDetail;